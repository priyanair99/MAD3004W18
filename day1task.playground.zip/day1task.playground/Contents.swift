//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var number = 4
var i:Int = 0

if number > 5{
    repeat
    {
        print("value = 5 * ", i, " = ", 5 * i)
        i = i + 1
    }
    while i < 10
}

else {
var j = 5
var temp = 1
    print("factorial of 5 is :")
repeat
{
    temp = temp * j
    j = j-1
    }
    while j > 0
    print(temp)
}
