//
//  main.swift
//  Singleton
//
//  Created by MacStudent on 2018-02-16.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

//var obj1 = Mysingleton()
//Mysingleton.instant.getMyName();

print(Mysingleton.getInstant().getMyName())
var obj2 = Mysingleton.getInstant()
print(obj2.getMyName())

var obj3 = Mysingleton.getInstant()
print(obj3.getMyName())
