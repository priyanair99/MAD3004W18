//: Playground - noun: a place where people can play

import UIKit
// to declare the variable
var str = "Hello, playground"

// use(str) to print string
print(str)

//use terminator to terminate the statement
print("this is our string: \(str)",terminator: " ")

//use separator for sepatrating multiple prompts
print("1","2","3","4","5",separator: "..")

// to print multiple records
var n1 = 10
print("number 1 : ",n1,"string : ",str)

var n2 = 20
print("number 2 : ",n2)

var sum = n1 + n2
print("sum is : ", sum)
print("sum = ", n1+n2)

/*
n1 = "test"
 print("n1 : ",n1)
 */

// to assign a variable
var a:Int = 10
print("a = ",a)

var greet:String = "Good Morning"
print("Greetings : ",greet)

var b:Float = 3.2
print("b = ",b)

var emoji = "😃";
print ("its a \(emoji) hour")

let pi = 3.14
//pi = 3.190
print("pi = ",pi)

//var pi = 10

let mynum:Int? //optional
mynum = 10

if mynum != nil {
    print("mynum : ", mynum!)
}
else{
    print("mynum is nil")
}

//optional values
let possibleNumber = "123" //hello
let convertednumber:Int?

convertednumber = Int(possibleNumber)

if convertednumber != nil{
    print("converted number", convertednumber!)
}
else{
    print("converted number is nil")
}

for i in 1...5{
    print ("i = ",i)
}

for i in 1..<5{
    print ("i = ",i)
}
for i in 1...5{
    print ("i = ",i)
}

let languages:[String]
languages = ["English", "Spanish", "French"]

for i in languages{
    print("languages : ", i)
}

//sum of numbers
var Number: Int = 1

for _ in 1...5{
    Number *= 5;
}
print("sum = ",Number)

/*
var Interval:Int = 5
for i in stride(from: 0, to: 50, by: Interval){
    print(i," ", terminator:" ")
*/
var j = 1

while (j < 5){
    print("value of j is \(j)")
    j = j + 1
}
repeat{
    print("Repeat : ",j)
j = j + 2
}while (j<=10)


// switch
var num1 = 10

switch num1 {
case 100 :
    print("value of num1 is 100")
 // fall through
case 10,15 :
    print("value of num1 is either 10 or 15")
    
case 5 :
    print("value of num1 is 5")
default :
    print("default case")
}
let approximateCount = 62
let countedThings = "moons orbiting saturn"
let naturalCount : String
switch approximateCount {
case 0 :
    naturalCount = "no"
case 1..<5:
    naturalCount = "a few"
case 5..<12:
    naturalCount = "several"
case 12..<100:
    naturalCount = "dozens of"
case 100..<1000:
    naturalCount = "hundreds of"
default:
    naturalCount = "many"
}
print("There are \(naturalCount) \(countedThings).")
